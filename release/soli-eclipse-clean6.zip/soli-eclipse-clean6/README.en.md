# Soli / 朔璃 - Codex Desktop Pet

Soli is an eclipse witch desktop companion for AI builders: quiet in idle, focused while working, and sharply expressive in high-energy reactions.

## Install

1. Create the pet folder:

```bash
mkdir -p ~/.codex/pets/soli
```

2. Copy the core files:

```bash
cp pet.json spritesheet.webp ~/.codex/pets/soli/
```

3. Restart Codex or switch pets, then choose **朔璃 / Soli**.

## Files

- `pet.json`: Codex pet config.
- `spritesheet.webp`: 8×9 atlas, 192×208 per cell.
- `contact-sheet.png`: state overview.
- `previews/`: GIF previews.
- `LICENSE-SOLI.txt`: usage license.

## Rights

Soli / 朔璃 and related character designs, sprites, animations, visual identity, and lore are original IP by trist. Personal desktop use is allowed. Redistribution, resale, commercial use, model training, minting as NFT, or use in third-party products is prohibited without written permission.
