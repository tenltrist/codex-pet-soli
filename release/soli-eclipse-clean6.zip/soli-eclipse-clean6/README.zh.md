# 朔璃 / Soli - Codex 桌面宠物

朔璃 / Soli 是一只月蚀魔女桌宠：平时安静陪伴，Codex 工作时进入负片月蚀状态双手捧月，高能状态会切到更强烈的反差形态。

## 安装

1. 新建目录：

```bash
mkdir -p ~/.codex/pets/soli
```

2. 把本文件夹里的文件复制进去：

```bash
cp pet.json spritesheet.webp ~/.codex/pets/soli/
```

3. 重启 Codex 或切换桌宠，选择 **朔璃 / Soli**。

## 文件

- `pet.json`：Codex 宠物配置。
- `spritesheet.webp`：8×9 atlas，单格 192×208。
- `contact-sheet.png`：状态总览。
- `previews/`：GIF 预览。
- `LICENSE-SOLI.txt`：使用许可。

## 版权

朔璃 / Soli 及相关角色设计、图像、动画、视觉识别与设定文本为 trist 的原创 IP。
允许个人桌面使用；未经书面授权，禁止转载打包、二次售卖、商业使用、模型训练、NFT 铸造或用于第三方产品。
